import javax.swing.*;
import java.awt.*;

public class About extends JFrame {

    public About() {
        JFrame frame = new JFrame();
        frame.setSize(1920, 1080);
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        ImageIcon logoIcon = new ImageIcon("logo.png");
        frame.setIconImage(logoIcon.getImage());

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(new Color(0x5aab28));

        ImageIcon image1 = new ImageIcon(new ImageIcon("About_BG.png").getImage().getScaledInstance(
                1535, 795, Image.SCALE_SMOOTH));
        JLabel imageLabel1 = new JLabel();
        imageLabel1.setIcon(image1);
        imageLabel1.setHorizontalAlignment(JLabel.CENTER);

        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(new Color(0x5aab28));

        JButton backButton = new JButton("Back");
        backButton.setBackground(new Color(0x99141e));
        backButton.setForeground(Color.WHITE);
        backButton.setFocusPainted(false);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));

        JButton loginButton = new JButton("Login");
        JButton signupButton = new JButton("Signup");
        signupButton.setFocusPainted(false);
        loginButton.setFocusPainted(false);
        signupButton.setBackground(new Color(0x99141e));
        signupButton.setForeground(Color.WHITE);
        loginButton.setBackground(new Color(0x336699));
        loginButton.setForeground(Color.WHITE);

        buttonPanel.add(loginButton);
        buttonPanel.add(signupButton);
        buttonPanel.setBackground(new Color(0x5aab28));

        topPanel.add(backButton, BorderLayout.WEST);
        topPanel.add(buttonPanel, BorderLayout.EAST);

        mainPanel.add(topPanel, BorderLayout.NORTH);
        mainPanel.add(imageLabel1, BorderLayout.CENTER);

        frame.add(mainPanel);

        frame.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new About());
    }
}
